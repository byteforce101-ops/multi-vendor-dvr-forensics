"""dvrforensics CLI package."""
